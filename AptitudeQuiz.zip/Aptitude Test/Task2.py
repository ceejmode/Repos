# Written by Cj Davis 9/15/2019
import requests
host ="https://clone.lingotek.com/api"
url = "https://clone.lingotek.com/api/project/6f883cda-f1da-4ffc-af40-db956fe64d95"
#authorization
headers = {
    'Authorization': "Bearer 08847a18-3855-42c9-9867-8c60ca1659a2",
    }
#get initial project, and title
response = requests.request("GET", url, headers=headers)
response = response.json()
title = response['properties']['title']
#get status link
status = response['links'][2]['href']
#concantenate to get status link
newUrl= host+status
#get status and word count
doc = requests.request("GET", newUrl, headers=headers)
doc =  doc.json()
#print
print(title + " -> " + str(doc['properties']['count']['word']) )
